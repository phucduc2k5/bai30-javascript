BAI TAP 30 - KIEM TRA HTML - JAVASCRIPT 05

Cach chay:
1. Giai nen file ZIP (neu nop file ZIP).
2. Mo file index.html bang Chrome, Edge hoac trinh duyet bat ky.
3. Nhap so bat dau va so ket thuc, sau do bam "Tinh tong".

Chuc nang:
- Tinh tong cac so chia het cho 3 trong khoang tu so bat dau den so ket thuc.
- Kiem tra du lieu dau vao la so nguyen.
- Bao loi neu so bat dau lon hon so ket thuc.
- Hien thi cac so chia het cho 3, so luong va tong.

Luu y: Trang web chay truc tiep tren trinh duyet, khong can cai dat them.
